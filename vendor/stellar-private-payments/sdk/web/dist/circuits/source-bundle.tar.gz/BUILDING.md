# Circuits source bundle

This bundle is provided to help recipients rebuild the compiled artifacts
shipped under `dist/circuits/` and to satisfy LGPL-3.0 expectations.

## Contents
- `circuits/src/`: Circom sources from this repository (including the vendored `circomlib`)
- `licenses/`: License texts for redistribution

## Build (example)
This archive is **not** a standalone Rust workspace. To rebuild the compiled
artifacts, you need the full repository checkout.

1) Obtain the repository sources (at the same revision used to build the
distributed artifacts):

- Repository: https://github.com/NethermindEth/stellar-private-payments
- Commit: e19e191ebd5e4a516c5c0f356d2d9e6584c265dd

2) Overlay the bundled circuits sources onto the repository checkout so that
`circomlib` is present at the expected path:

```
cp -R circuits/src/ <REPO_ROOT>/circuits/src/
```

At minimum, ensure:
`<REPO_ROOT>/circuits/src/circomlib` matches revision: 35e54ea21da3e8762557234298dbb553c175ea8d

3) Build the circuits crate from the repository root:

```
cargo build -p circuits --release
```

The build produces circuit artifacts under Cargo `OUT_DIR` and the frontend
build copies them into `dist/circuits/` via Trunk hooks.
